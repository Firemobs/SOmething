# Minecraft-Gift_code-gen-Checker

Minecraft Gift code Generator with Checker

The checker use your `Microsoft Minecraft Account`

1. If You Don't have a Minecraft Account With Microsoft, Go Create one

2. Download `Chromedriver` (Download the same version as your Chrome Browser)

3. Run the `main.py` Script

4. always Check The `Terminal` For instructions

5. Login With Your Microsoft Account from the new opened Chrome browser  ("Chromedriver")

6. Then press `1` in the `Terminal` To resume the program

7. Sit Back and let the program do his Job.

Good Luck
